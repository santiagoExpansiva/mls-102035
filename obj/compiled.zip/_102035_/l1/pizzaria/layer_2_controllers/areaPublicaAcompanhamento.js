/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/areaPublicaAcompanhamento.ts" enhancement="_blank" />
import { ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
async function getPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPedido");
}
async function getTempoAlvoEtapaRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaTempoAlvoEtapa");
}
async function getItemPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaItemPedido");
}
async function getEntregaRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaEntrega");
}
async function getConfiguracaoWhatsAppRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaConfiguracaoWhatsApp");
}
export async function getPedidoResumoPublico(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const rows = await repo.findMany();
    const filtered = input?.pedidoId ? rows.filter((item) => item.pedidoId === input.pedidoId) : rows;
    return filtered[0];
}
export async function listPedidoEtapasPublico(ctx, input) {
    const repo = await getTempoAlvoEtapaRepository(ctx);
    const rows = await repo.findMany();
    const filtered = input?.pedidoId ? rows.filter((item) => item.pedidoId === input.pedidoId) : rows;
    return filtered;
}
export async function listItensPedidoPublico(ctx, input) {
    const repo = await getItemPedidoRepository(ctx);
    const rows = await repo.findMany();
    const filtered = input?.pedidoId ? rows.filter((item) => item.pedidoId === input.pedidoId) : rows;
    return filtered;
}
export async function getEntregaPublica(ctx, input) {
    const repo = await getEntregaRepository(ctx);
    const rows = await repo.findMany();
    const filtered = input?.pedidoId ? rows.filter((item) => item.pedidoId === input.pedidoId) : rows;
    return filtered[0];
}
export async function getConfiguracaoWhatsAppPublica(ctx) {
    const repo = await getConfiguracaoWhatsAppRepository(ctx);
    const rows = await repo.findMany();
    return rows[0];
}
export const areaPublicaAcompanhamentoGetPedidoResumoPublicoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPedidoResumoPublico(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaAcompanhamentoListPedidoEtapasPublicoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listPedidoEtapasPublico(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaAcompanhamentoListItensPedidoPublicoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listItensPedidoPublico(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaAcompanhamentoGetEntregaPublicaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getEntregaPublica(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaAcompanhamentoGetConfiguracaoWhatsAppPublicaHandler = async ({ request, ctx }) => {
    return ok(await getConfiguracaoWhatsAppPublica(ctx));
};
