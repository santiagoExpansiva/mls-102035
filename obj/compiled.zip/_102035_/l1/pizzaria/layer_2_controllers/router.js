export function createPizzariaRouter() {
    return new Map([]);
}
