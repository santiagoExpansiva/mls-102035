/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/confirmacaoImpressaoComanda.ts" enhancement="_blank" />
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
async function getPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPedido");
}
async function getItemPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaItemPedido");
}
export async function getPedidoResumoImpressao(ctx, input) {
    const pedidoRepo = await getPedidoRepository(ctx);
    const itemPedidoRepo = await getItemPedidoRepository(ctx);
    let pedidos = await pedidoRepo.findMany();
    if (input?.pedidoId !== undefined) {
        pedidos = pedidos.filter((item) => item.id === input.pedidoId);
    }
    const pedido = pedidos[0];
    if (!pedido) {
        return undefined;
    }
    const itens = (await itemPedidoRepo.findMany()).filter((item) => item.pedidoId === pedido.id);
    return {
        ...pedido,
        itens
    };
}
export async function carregarResumo(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pedido not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.criadoEm !== undefined ? { criadoEm: input.criadoEm } : {}),
        ...(input.atualizadoEm !== undefined ? { atualizadoEm: input.atualizadoEm } : {}),
        ...(input.itens !== undefined ? { itens: input.itens } : {}),
        ...(input.responsavelAtendimento !== undefined ? { responsavelAtendimento: input.responsavelAtendimento } : {}),
        ...(input.observacoes !== undefined ? { observacoes: input.observacoes } : {}),
        ...(input.formaPagamento !== undefined ? { formaPagamento: input.formaPagamento } : {}),
        ...(input.statusPagamento !== undefined ? { statusPagamento: input.statusPagamento } : {}),
        ...(input.observacaoCritica !== undefined ? { observacaoCritica: input.observacaoCritica } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function imprimirComanda(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pedido not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.criadoEm !== undefined ? { criadoEm: input.criadoEm } : {}),
        ...(input.atualizadoEm !== undefined ? { atualizadoEm: input.atualizadoEm } : {}),
        ...(input.itens !== undefined ? { itens: input.itens } : {}),
        ...(input.responsavelAtendimento !== undefined ? { responsavelAtendimento: input.responsavelAtendimento } : {}),
        ...(input.observacoes !== undefined ? { observacoes: input.observacoes } : {}),
        ...(input.formaPagamento !== undefined ? { formaPagamento: input.formaPagamento } : {}),
        ...(input.statusPagamento !== undefined ? { statusPagamento: input.statusPagamento } : {}),
        ...(input.observacaoCritica !== undefined ? { observacaoCritica: input.observacaoCritica } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const confirmacaoImpressaoComandaGetPedidoResumoImpressaoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPedidoResumoImpressao(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const confirmacaoImpressaoComandaCarregarResumoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await carregarResumo(ctx, {
        id: typeof params.id === "string" ? params.id : "",
        status: typeof params.status === "string" ? params.status : undefined,
        criadoEm: params.criadoEm !== undefined ? params.criadoEm : undefined,
        atualizadoEm: params.atualizadoEm !== undefined ? params.atualizadoEm : undefined,
        itens: params.itens !== undefined ? params.itens : undefined,
        responsavelAtendimento: typeof params.responsavelAtendimento === "string" ? params.responsavelAtendimento : undefined,
        observacoes: typeof params.observacoes === "string" ? params.observacoes : undefined,
        formaPagamento: typeof params.formaPagamento === "string" ? params.formaPagamento : undefined,
        statusPagamento: typeof params.statusPagamento === "string" ? params.statusPagamento : undefined,
        observacaoCritica: typeof params.observacaoCritica === "string" ? params.observacaoCritica : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const confirmacaoImpressaoComandaImprimirComandaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await imprimirComanda(ctx, {
        id: typeof params.id === "string" ? params.id : "",
        status: typeof params.status === "string" ? params.status : undefined,
        criadoEm: params.criadoEm !== undefined ? params.criadoEm : undefined,
        atualizadoEm: params.atualizadoEm !== undefined ? params.atualizadoEm : undefined,
        itens: params.itens !== undefined ? params.itens : undefined,
        responsavelAtendimento: typeof params.responsavelAtendimento === "string" ? params.responsavelAtendimento : undefined,
        observacoes: typeof params.observacoes === "string" ? params.observacoes : undefined,
        formaPagamento: typeof params.formaPagamento === "string" ? params.formaPagamento : undefined,
        statusPagamento: typeof params.statusPagamento === "string" ? params.statusPagamento : undefined,
        observacaoCritica: typeof params.observacaoCritica === "string" ? params.observacaoCritica : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
