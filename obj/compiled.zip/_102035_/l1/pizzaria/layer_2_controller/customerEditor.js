import { AppError, ok } from "_102034_/l1/server/layer_2_controllers/contracts.js";
async function getCustomerRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaCustomer");
}
export async function getCustomer(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const rows = await repo.findMany();
    const filtered = input?.customerId ? rows.filter((item) => item.customerId === input.customerId) : rows;
    return filtered[0];
}
export async function load(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Customer not found", 404);
    const merged = {
        ...existing,
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.phone !== undefined ? { phone: input.phone } : {}),
        ...(input.notes !== undefined ? { notes: input.notes } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function save(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Customer not found", 404);
    const merged = {
        ...existing,
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.phone !== undefined ? { phone: input.phone } : {}),
        ...(input.notes !== undefined ? { notes: input.notes } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function deleteCustomer(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Customer not found", 404);
    await repo.delete({ where: { customerId: input.customerId } });
    return existing;
}
export const customerEditorGetCustomerHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getCustomer(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined
    }));
};
export const customerEditorLoadHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await load(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : "",
        name: typeof params.name === "string" ? params.name : undefined,
        phone: typeof params.phone === "string" ? params.phone : undefined,
        notes: typeof params.notes === "string" ? params.notes : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const customerEditorSaveHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await save(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : "",
        name: typeof params.name === "string" ? params.name : undefined,
        phone: typeof params.phone === "string" ? params.phone : undefined,
        notes: typeof params.notes === "string" ? params.notes : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const customerEditorDeleteHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await deleteCustomer(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : "",
        name: typeof params.name === "string" ? params.name : undefined,
        phone: typeof params.phone === "string" ? params.phone : undefined,
        notes: typeof params.notes === "string" ? params.notes : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
