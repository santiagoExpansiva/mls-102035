/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/customerEditor.ts" enhancement="_blank" />
import { AppError, ok } from "_102034_/l1/server/layer_2_controllers/contracts.js";
async function getCustomerRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaCustomer");
}
async function getCustomerOrderHistoryRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaCustomerOrderHistory");
}
export async function getCustomer(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const rows = await repo.findMany();
    let filtered = rows;
    if (input?.customerId) {
        filtered = filtered.filter((item) => item.customerId === input.customerId);
    }
    return filtered[0];
}
export async function viewCustomerHistory(ctx, input) {
    const repo = await getCustomerOrderHistoryRepository(ctx);
    const rows = await repo.findMany();
    let filtered = rows;
    if (input?.customerId) {
        filtered = filtered.filter((item) => item.customerId === input.customerId);
    }
    return filtered;
}
export async function load(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Customer not found", 404);
    const merged = {
        ...existing,
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.phone !== undefined ? { phone: input.phone } : {}),
        ...(input.notes !== undefined ? { notes: input.notes } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function save(ctx, input) {
    const repo = await getCustomerRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Customer not found", 404);
    const merged = {
        ...existing,
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.phone !== undefined ? { phone: input.phone } : {}),
        ...(input.notes !== undefined ? { notes: input.notes } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function loadHistory(ctx, input) {
    const repo = await getCustomerOrderHistoryRepository(ctx);
    const existing = await repo.findOne({ where: { customerId: input.customerId } });
    if (!existing)
        throw new AppError("NOT_FOUND", "CustomerOrderHistory not found", 404);
    const merged = {
        ...existing,
        ...(input.orderId !== undefined ? { orderId: input.orderId } : {}),
        ...(input.orderDate !== undefined ? { orderDate: input.orderDate } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const customerEditorGetCustomerHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getCustomer(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined
    }));
};
export const customerEditorViewCustomerHistoryHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await viewCustomerHistory(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined
    }));
};
export const customerEditorLoadHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await load(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined,
        name: typeof params.name === "string" ? params.name : undefined,
        phone: typeof params.phone === "string" ? params.phone : undefined,
        notes: typeof params.notes === "string" ? params.notes : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const customerEditorSaveHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await save(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined,
        name: typeof params.name === "string" ? params.name : undefined,
        phone: typeof params.phone === "string" ? params.phone : undefined,
        notes: typeof params.notes === "string" ? params.notes : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const customerEditorLoadHistoryHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadHistory(ctx, {
        customerId: typeof params.customerId === "string" ? params.customerId : undefined,
        orderId: typeof params.orderId === "string" ? params.orderId : undefined,
        orderDate: params.orderDate !== undefined ? params.orderDate : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
