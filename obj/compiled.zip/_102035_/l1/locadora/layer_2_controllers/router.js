import { veiculosCadastroGetStatusVeiculoOptionsHandler, } from '/_102035_/l1/locadora/layer_2_controllers/veiculosCadastro.js';
import { veiculosListaListVeiculosHandler, } from '/_102035_/l1/locadora/layer_2_controllers/veiculosLista.js';
export function createPizzariaRouter() {
    return new Map([
        ['locadora.getStatusVeiculoOptions', veiculosCadastroGetStatusVeiculoOptionsHandler],
        ['locadora.listVeiculos', veiculosListaListVeiculosHandler],
    ]);
}
