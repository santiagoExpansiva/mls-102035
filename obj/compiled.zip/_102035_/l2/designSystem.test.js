/// <mls fileReference="_102035_/l2/designSystem.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
