declare module "_102035_/l1/pizzaria/module" {
    export interface PizzariaCustomer {
        customerId: string;
        name: string;
        phone: string;
        notes?: string;
    }
    export interface PizzariaCustomerOrderHistory {
        customerId: string;
        orderId: string;
        orderDate: any;
    }
    export interface PizzariaServiceTimeTarget {
        status: 'recebido' | 'em preparo' | 'pronto' | 'entregue';
        targetMinutes: number;
    }
    export interface PizzariaInventoryReplenishmentRule {
        productId: string;
        minimumStock: number;
        replenishmentAlert: 'ativo' | 'inativo';
    }
    export interface PizzariaPhoneOrderScript {
        scriptId: string;
        title: string;
        content: string;
        status: 'ativo' | 'inativo';
    }
    export interface PizzariaPhoneOrderChecklist {
        checklistId: string;
        title: string;
        items: string;
        status: 'ativo' | 'inativo';
    }
    export interface PizzariaUpdateCustomerParams {
        customerId: string;
        name?: string;
        phone?: string;
        notes?: string;
        author?: string;
    }
    export interface PizzariaUpdateCustomerOrderHistoryParams {
        customerId: string;
        orderId?: string;
        orderDate?: any;
        author?: string;
    }
    export interface PizzariaUpdateServiceTimeTargetParams {
        status: PizzariaServiceTimeTarget['status'];
        targetMinutes?: number;
        author?: string;
    }
    export interface PizzariaUpdateInventoryReplenishmentRuleParams {
        productId: string;
        minimumStock?: number;
        replenishmentAlert?: PizzariaInventoryReplenishmentRule['replenishmentAlert'];
        author?: string;
    }
    export interface PizzariaUpdatePhoneOrderScriptParams {
        scriptId: string;
        title?: string;
        content?: string;
        status?: PizzariaPhoneOrderScript['status'];
        author?: string;
    }
    export interface PizzariaUpdatePhoneOrderChecklistParams {
        checklistId: string;
        title?: string;
        items?: string;
        status?: PizzariaPhoneOrderChecklist['status'];
        author?: string;
    }
    export interface PizzariaSeedResult {
        insertedCount: number;
        totalCount: number;
        seededAt: string;
    }
}
declare module "_102035_/l1/pizzaria/layer_2_controller/customerEditor" {
    import { PizzariaCustomer, PizzariaCustomerOrderHistory, PizzariaUpdateCustomerParams, PizzariaUpdateCustomerOrderHistoryParams } from "_102035_/l1/pizzaria/module";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function getCustomer(ctx: RequestContext, input?: {
        customerId?: string;
    }): Promise<PizzariaCustomer | undefined>;
    export function viewCustomerHistory(ctx: RequestContext, input?: {
        customerId?: string;
    }): Promise<PizzariaCustomerOrderHistory[]>;
    export function load(ctx: RequestContext, input: PizzariaUpdateCustomerParams): Promise<PizzariaCustomer>;
    export function save(ctx: RequestContext, input: PizzariaUpdateCustomerParams): Promise<PizzariaCustomer>;
    export function loadHistory(ctx: RequestContext, input: PizzariaUpdateCustomerOrderHistoryParams): Promise<PizzariaCustomerOrderHistory>;
    export const customerEditorGetCustomerHandler: BffHandler;
    export const customerEditorViewCustomerHistoryHandler: BffHandler;
    export const customerEditorLoadHandler: BffHandler;
    export const customerEditorSaveHandler: BffHandler;
    export const customerEditorLoadHistoryHandler: BffHandler;
}
declare module "_102035_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102035_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102035_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102035_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102035_/l2/pizzaria/adminDashboard.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/customerEditor.defs" {
    export const definition: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: ({
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                routeParam: string;
                            };
                        }[];
                        itemFields?: undefined;
                        editable?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: string[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: {
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                routeParam: string;
                            };
                        }[];
                        editable: boolean;
                        fields?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: string[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                })[];
            } | {
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                }[];
            })[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
            }[];
        }[];
        status: string;
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/customerEditor.defs.ts).definition]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l1/pizzaria/module.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/customerEditor.defs.ts).definition]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l1/pizzaria/module.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/customerEditor.defs.ts).definition]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/pizzaria/web/shared/customerEditor.ts)]]\n```\n";
    export const materializeIndex: {
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
    }[];
}
declare module "_102035_/l2/pizzaria/customerHistory.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/customerList.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/deliveryAssignment.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/deliveryTracking.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/inventoryAdjustment.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/inventoryMinimumSettings.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/inventoryOverview.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/login.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/module.defs" {
    export const ontology: {
        meta: {
            userLanguage: string;
            moduleName: string;
            userPromptOriginal: string;
            userPromptFinal: string;
        };
        ontology: {
            entities: {
                Customer: {
                    description: string;
                    fields: {
                        customerId: {
                            type: string;
                        };
                        name: {
                            type: string;
                        };
                        phone: {
                            type: string;
                        };
                        notes: {
                            type: string;
                            required: boolean;
                        };
                    };
                };
                CustomerOrderHistory: {
                    description: string;
                    fields: {
                        customerId: {
                            type: string;
                        };
                        orderId: {
                            type: string;
                        };
                        orderDate: {
                            type: string;
                        };
                    };
                };
                ServiceTimeTarget: {
                    description: string;
                    fields: {
                        status: {
                            type: string;
                            values: string[];
                        };
                        targetMinutes: {
                            type: string;
                        };
                    };
                };
                InventoryReplenishmentRule: {
                    description: string;
                    fields: {
                        productId: {
                            type: string;
                        };
                        minimumStock: {
                            type: string;
                        };
                        replenishmentAlert: {
                            type: string;
                            values: string[];
                        };
                    };
                };
                PhoneOrderScript: {
                    description: string;
                    fields: {
                        scriptId: {
                            type: string;
                        };
                        title: {
                            type: string;
                        };
                        content: {
                            type: string;
                        };
                        status: {
                            type: string;
                            values: string[];
                        };
                    };
                };
                PhoneOrderChecklist: {
                    description: string;
                    fields: {
                        checklistId: {
                            type: string;
                        };
                        title: {
                            type: string;
                        };
                        items: {
                            type: string;
                            constraints: string;
                        };
                        status: {
                            type: string;
                            values: string[];
                        };
                    };
                };
            };
        };
        rules: {
            rule1: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule2: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule3: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule4: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule5: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule6: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule7: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule8: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule9: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule10: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule11: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule12: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule13: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule14: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule15: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule16: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
        };
        capabilities: {
            productCatalog: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            orderManagement: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            deliveryManagement: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            inventoryControl: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            reporting: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            customerManagement: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            serviceTimeManagement: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            phoneOrderChecklist: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
        };
    };
}
declare module "_102035_/l2/pizzaria/orderCreateCounter.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/orderCreatePhone.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/orderDetails.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/orderList.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/phoneChecklistManagement.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/phoneScriptManagement.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/productEditor.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/productList.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/reportSalesPeriod.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/reportTopItems.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/reportsOverview.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/serviceTimeTargets.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/staffDashboard.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/web/shared/customerEditor" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PizzariaCustomer, PizzariaCustomerOrderHistory, PizzariaUpdateCustomerParams } from "_102035_/l1/pizzaria/module";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingCustomer: string;
        loadingCustomerHistory: string;
        couldNotLoad: string;
        couldNotSave: string;
        savedSuccessfully: string;
        itemsAvailable: string;
        statusReady: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        customerId: string;
        name: string;
        phone: string;
        notes: string;
        orderId: string;
        orderDate: string;
    };
    type MessageType = typeof message_en;
    export class PizzariaCustomerEditorBase extends CollabLitElement {
        static properties: {
            customerDetail: {
                state: boolean;
            };
            customerOrderHistory: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
        };
        customerDetail: PizzariaCustomer | undefined;
        customerOrderHistory: PizzariaCustomerOrderHistory[];
        status: string;
        protected msg: MessageType;
        constructor();
        createRenderRoot(): this;
        connectedCallback(): void;
        protected loadInitialData(params?: {
            customerId?: string;
        }, options?: BffClientOptions): Promise<void>;
        loadGetCustomer(params?: {
            customerId?: string;
        }, options?: BffClientOptions): Promise<void>;
        loadViewCustomerHistory(params?: {
            customerId?: string;
        }, options?: BffClientOptions): Promise<void>;
        save(params: PizzariaUpdateCustomerParams, signal?: AbortSignal): Promise<void>;
        handleSaveSubmit(event: SubmitEvent): void;
    }
}
declare module "_102035_/l2/pizzaria/web/desktop/page11/customerEditor" {
    import { PizzariaCustomerEditorBase } from "_102035_/l2/pizzaria/web/shared/customerEditor";
    export class PizzariaWebDesktopCustomerEditorPage extends PizzariaCustomerEditorBase {
        render(): any;
    }
}
