declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102035_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102035_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
        layouts: {
            1: {
                name: string;
                skill: string;
            };
        };
        designSystems: {
            1: {
                name: string;
                skill: string;
            };
        };
    };
}
